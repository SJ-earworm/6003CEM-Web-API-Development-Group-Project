const express = require('express');
const axios = require('axios');
const cors = require('cors');

const app = express();
const PORT = 5000;

app.use(cors());


//API KEY FOR SPOTS API / FETCH DATA USING API KEY VIKIIII
app.get('/api/news/sports', async (req, res) => {
    try {
        const response = await axios.get('https://newsapi.org/v2/top-headlines', {
            params: {
                country: 'my',
                category: 'sports',
                apiKey: '7ca08a73c4b04972877d67101aabd31c'
            }
        });
        console.log(response.data);  // Log the response data
        res.json(response.data);
    } catch (error) {
        console.error(error);
        res.status(500).send('Server Error');
    }
});

// API KEY FOR TOURISM API / FETCH LATEST DATA SAME LIKE TOP CLARENCE
app.get('/api/news/tourism', async (req, res) => {
    try {
        const response = await axios.get('https://newsapi.org/v2/top-headlines', {
            params: {
                country: 'my',
                category: 'business',  
                apiKey: 'ee3dad1511484effb0aebe5c03edf7bf'
            }
        });
        console.log(response.data);  
        res.json(response.data);
    } catch (error) {
        console.error(error);
        res.status(500).send('Server Error');
    }
});

// ENDPOINT FOR ENTERTAINMENT NEWS SARAH
app.get('/api/news/entertainment', async (req, res) => {
    try {
        const response = await axios.get('https://newsapi.org/v2/top-headlines', {
            params: {
                country: 'my',
                category: 'entertainment',
                apiKey: '6e486882e2c14a678cec2533aefb571d'
            }
        });
        res.json(response.data);
    } catch (error) {
        console.error(error);
        res.status(500).send('Server Error');
    }
});

// ENDPOINT FOR SCIENCE CATEGORY CKOKHAN
app.get('/api/news/science', async (req, res) => {
    try {
        const response = await axios.get('https://gnews.io/api/v4/top-headlines', {
            params: {
                topic: 'science',
                country: 'my',
                token: 'a49dc5caead5fc77840446f06500612b' 
            }
        });
        res.json(response.data);
    } catch (error) {
        console.error('Error fetching news:', error.message); 
        res.status(500).send('Server Error');
    }
});

app.listen(PORT, () => {
    console.log(`Server is running on http://localhost:${PORT}`);
});
