import React, { useState } from 'react';
import SportsNews from './sportsnews';
import TourismNews from './tourismscreen';
import EntertainmentNews from './entertainmentnews';
import ScienceNews from './sciencenews';
import './App.css';

function App() {
    const [view, setView] = useState('sports');

    return (
        <div className="App">
            <header className="App-header">
                <h1>News in Malaysia</h1>
                <nav>
                    <button onClick={() => setView('sports')}>Sports News</button>
                    <button onClick={() => setView('tourism')}>Tourism News</button>
                    <button onClick={() => setView('entertainment')}>Entertainment News</button>
                    <button onClick={() => setView('science')}>Science News</button>
                </nav>
            </header>
            {view === 'sports' && <SportsNews />}
            {view === 'tourism' && <TourismNews />}
            {view === 'entertainment' && <EntertainmentNews />}
            {view === 'science' && <ScienceNews />}
        </div>
    );
}

export default App;
