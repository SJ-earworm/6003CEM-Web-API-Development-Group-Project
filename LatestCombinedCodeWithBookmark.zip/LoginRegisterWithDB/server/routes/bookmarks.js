const express = require("express");
const router = express.Router();
const { User } = require("../models/user");

// Adding bookmarks
router.post("/api/bookmarks", async (req, res) => {
    try {
        const {title, url} = req.body;
        console.log("** REQUEST BODY **", req.body);
        const user = await User.findById(req.user._id);
        // const user = req.user;
        if(!user)return res.status(404).send('User not found');

        user.bookmark.push({title, url});
        await user.save();

        // respond with success message
        res.status(201).send(user.bookmarks);
    } catch(error) {
        res.status(500).send('Server error');
    }
});

// Deleting bookmarks
 router.delete("/api/bookmarks", async (req, res) => {
     try {
         const {title, url} = req.body;
         console.log("** REQUEST BODY **", req.body);
         const user = await User.findById(req.user._id);
         // const user = req.user;
         if(!user)return res.status(404).send('User not found');

         user.bookmark.push({title, url});
         await user.save();

         // respond with success message
         res.status(201).send(user.bookmarks);
     } catch(error) {
         res.status(500).send('Server error');
     }
 });

// Retrieving bookmarks
router.get("/bookmarks", async (req, res) => {
    try {
        const user = await User.findById(req.user._id);
        // const user = req.user;
        if(!user) return res.status(404).send('User not found');

        res.send(user.bookmarks);
    } catch(error) {
        res.status(500).send('Server error');
    }
});

module.exports = router;