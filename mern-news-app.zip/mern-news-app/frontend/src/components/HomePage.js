import React, { useEffect, useState } from 'react';
import axios from 'axios';
import ArticleCard from './ArticleCard';
import { FaBars, FaHome, FaBusinessTime, FaTv, FaHeartbeat, FaFlask, FaFootballBall, FaLaptop, FaPlane, FaUser } from 'react-icons/fa';
import styles from './HomePage.module.css';
import { useNavigate } from 'react-router-dom'; // Assuming you're using React Router for navigation

const categories = [
  { name: 'general', icon: <FaHome /> },
  { name: 'business', icon: <FaBusinessTime /> },
  { name: 'entertainment', icon: <FaTv /> },
  { name: 'health', icon: <FaHeartbeat /> },
  { name: 'science', icon: <FaFlask /> },
  { name: 'sports', icon: <FaFootballBall /> },
  { name: 'technology', icon: <FaLaptop /> },
  { name: 'tourism', icon: <FaPlane /> },
];
const sortOptions = ['Newest', 'Oldest',];

const HomePage = () => {
  const [articles, setArticles] = useState([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [category, setCategory] = useState('');
  const [startDate, setStartDate] = useState('');
  const [endDate, setEndDate] = useState('');
  const [sortBy, setSortBy] = useState('');
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [dropdownOpen, setDropdownOpen] = useState(false);
  const navigate = useNavigate();

  useEffect(() => {
    const fetchArticles = async () => {
      try {
        const params = {
          q: searchQuery,
          category,
          from: startDate,
          to: endDate,
          sortBy,
          apiKey: process.env.REACT_APP_NEWS_API_KEY
        };
        const queryString = Object.keys(params)
          .filter(key => params[key])
          .map(key => `${key}=${encodeURIComponent(params[key])}`)
          .join('&');

        const response = await axios.get(`https://newsapi.org/v2/top-headlines?${queryString}`);
        setArticles(response.data.articles);
      } catch (error) {
        console.error('Error fetching articles:', error);
      }
    };

    fetchArticles();
  }, [searchQuery, category, startDate, endDate, sortBy]);

  const handleSearch = (e) => {
    e.preventDefault();
    setSearchQuery(searchQuery);
  };

  const handleSignOut = () => {
    // Implement sign out logic
    navigate('/login');
  };

  return (
    <div className={styles.container}>
      <div className={`${styles.sidebar} ${sidebarOpen ? styles.open : ''}`}>
        <div className={styles.sidebarHeader}>
          <h2>News</h2>
          <FaBars className={styles.hamburger} onClick={() => setSidebarOpen(!sidebarOpen)} />
        </div>
        <ul className={styles.sidebarList}>
          <li className={styles.sidebarTitle}>Latest</li>
          <li className={styles.sidebarTitle}>Past</li>
          <li className={styles.sidebarTitle}>Categories</li>
          {categories.map((cat, index) => (
            <li key={index} onClick={() => setCategory(cat.name)} className={styles.sidebarItem}>
              {cat.icon}
              <span>{cat.name.charAt(0).toUpperCase() + cat.name.slice(1)}</span>
            </li>
          ))}
        </ul>
      </div>
      <div className={styles.mainContent}>
        <div className={styles.navBar}>
          <button onClick={() => navigate('/home')} className={styles.navButton}>
            <FaHome /> Home
          </button>
          <form onSubmit={handleSearch} className={styles.searchForm}>
            <input
              type="text"
              placeholder="Search..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />
            <select onChange={(e) => setCategory(e.target.value)}>
              <option value="">All Categories</option>
              {categories.map((cat, index) => (
                <option key={index} value={cat.name}>{cat.name.charAt(0).toUpperCase() + cat.name.slice(1)}</option>
              ))}
            </select>
            <input
              type="date"
              value={startDate}
              onChange={(e) => setStartDate(e.target.value)}
            />
            <input
              type="date"
              value={endDate}
              onChange={(e) => setEndDate(e.target.value)}
            />
            <select onChange={(e) => setSortBy(e.target.value)}>
              <option value="">Sort By</option>
              {sortOptions.map((option, index) => (
                <option key={index} value={option}>{option.charAt(0).toUpperCase() + option.slice(1)}</option>
              ))}
            </select>
            <button type="submit">Search</button>
          </form>
          <div className={styles.profileDropdown} onClick={() => setDropdownOpen(!dropdownOpen)}>
            <FaUser /> Profile
            {dropdownOpen && (
              <div className={styles.dropdownContent}>
                <button onClick={() => navigate('/profile/settings')}>Settings</button>
                <button onClick={handleSignOut}>Sign Out</button>
              </div>
            )}
          </div>
        </div>
        <div className={styles.articles}>
          {articles.map((article, index) => (
            <ArticleCard key={index} article={article} />
          ))}
        </div>
      </div>
    </div>
  );
};

export default HomePage;
