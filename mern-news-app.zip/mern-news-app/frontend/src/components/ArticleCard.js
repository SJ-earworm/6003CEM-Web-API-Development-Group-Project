import React from 'react';
import styles from './ArticleCard.module.css';

const ArticleCard = ({ article }) => {
  return (
    <div className={styles.card}>
      <img src={article.urlToImage} alt={article.title} className={styles.image} />
      <div className={styles.content}>
        <h2>{article.title}</h2>
        <p>{article.description}</p>
        <a href={article.url} target="_blank" rel="noopener noreferrer">Read More</a>
      </div>
    </div>
  );
};

export default ArticleCard;
