import React from 'react';
import { BrowserRouter as Router, Route, Routes, Navigate } from "react-router-dom";
import HomePage from './components/HomePage';
import Login from './components/Login/index';
import Signup from './components/Singup/index';
import ProfilePage from './components/ProfilePage'; 
import ProfileSettings from './components/ProfileSettings';

const App = () => {
  return (
    <Routes>
      <Route path="/" element={<Navigate to="/login" />} />
      <Route path="/login" element={<Login />} />
      <Route path="/signup" element={<Signup />} />
      <Route path="/home" element={<HomePage />} />
      <Route path="/profile" element={<ProfilePage />} />
      <Route path="/profile/settings" element={<ProfileSettings />} />
    </Routes>
  );
};

export default App;
