const express = require('express');
const { getArticles, bookmarkArticle, getBookmarks } = require('../controllers/articleController');
const { protect } = require('../middleware/authMiddleware');

const router = express.Router();

router.get('/', getArticles);
router.post('/bookmark', protect, bookmarkArticle);
router.get('/bookmarks', protect, getBookmarks);

module.exports = router;
