const axios = require('axios');
const Article = require('../models/Article');
const User = require('../models/User');

const getArticles = async (req, res) => {
  try {
    const response = await axios.get(`https://newsapi.org/v2/top-headlines?country=in&apiKey=${process.env.NEWS_API_KEY}`);
    res.json(response.data.articles);
  } catch (error) {
    res.status(500).json({ message: 'Failed to fetch articles', error });
  }
};

const bookmarkArticle = async (req, res) => {
  const { articleId } = req.body;
  try {
    const user = await User.findById(req.user.id);
    user.bookmarks.push(articleId);
    await user.save();
    res.status(201).json({ message: 'Article bookmarked' });
  } catch (error) {
    res.status(500).json({ message: 'Failed to bookmark article', error });
  }
};

const getBookmarks = async (req, res) => {
  try {
    const user = await User.findById(req.user.id).populate('bookmarks');
    res.json(user.bookmarks);
  } catch (error) {
    res.status(500).json({ message: 'Failed to fetch bookmarks', error });
  }
};

module.exports = {
  getArticles,
  bookmarkArticle,
  getBookmarks,
};
