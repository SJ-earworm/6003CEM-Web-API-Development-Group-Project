import React, { useState, useEffect, useRef } from 'react';
import { FaHome, FaBusinessTime, FaTv, FaFlask, FaFootballBall, FaBookmark, FaRegBookmark } from 'react-icons/fa';
import { useNavigate } from 'react-router-dom';
import Cookies from 'js-cookie';
import styles from './HomeScreen.module.css';

const API_URL = 'https://newsapi.org/v2/top-headlines';
const GNEWS_URL = 'https://gnews.io/api/v4/top-headlines';

const categories = [
  { name: 'general', icon: <FaHome /> },
  { name: 'business', icon: <FaBusinessTime /> },
  { name: 'entertainment', icon: <FaTv /> },
  { name: 'science', icon: <FaFlask /> },
  { name: 'sports', icon: <FaFootballBall /> },
];

const apiKeys = {
  general: '54620fa26a0648fdb7ef7784abceccf1',
  business: 'ee3dad1511484effb0aebe5c03edf7bf',
  entertainment: '6e486882e2c14a678cec2533aefb571d',
  science: 'a49dc5caead5fc77840446f06500612b',
  sports: '7ca08a73c4b04972877d67101aabd31c',
};

const HomeScreen = () => {
  const [selectedCategory, setSelectedCategory] = useState('general');
  const [articles, setArticles] = useState([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [isSearching, setIsSearching] = useState(false);
  const [selectedDate, setSelectedDate] = useState('');
  const navigate = useNavigate();
  const [userName, setUserName] = useState('');
  const [userLastName, setUserLastName] = useState('');
  const [searchHistory, setSearchHistory] = useState([]);
  const [isDropdownOpen, setIsDropdownOpen] = useState(false);
  const [bookmark, setBookmark] = useState([]); // state to handle bookmark saving

  useEffect(() => {
    const firstName = localStorage.getItem('firstName');
    const lastName = localStorage.getItem('lastName');
    const email = localStorage.getItem('email'); // Retrieve email from localStorage

    if (firstName) {
      setUserName(firstName);
    }
    if (lastName) {
      setUserLastName(lastName);
    }
    if (email) {
      console.log('Email found:', email);
    }
  }, []);

  useEffect(() => {
    const handleClickOutside = (event) => {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target)) {
        setIsDropdownOpen(false);
      }
    };

    if (isDropdownOpen) {
      document.addEventListener('mousedown', handleClickOutside);
    } else {
      document.removeEventListener('mousedown', handleClickOutside);
    }

    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, [isDropdownOpen]);

  const dropdownRef = useRef(null);

  const toggleDropdown = () => {
    setIsDropdownOpen(!isDropdownOpen);
  };

  const fetchNews = async (category, date = '') => {
    try {
      let url = category === 'science'
        ? `${GNEWS_URL}?topic=${category}&country=my&token=${apiKeys[category]}`
        : `${API_URL}?country=my&category=${category}&apiKey=${apiKeys[category]}`;

      if (date) {
        url += `&from=${date}&to=${date}`;
      }

      const response = await fetch(url);
      const data = await response.json();
      setArticles(data.articles);
    } catch (error) {
      console.error('Error fetching news:', error);
    }
  };

  const fetchSearchResults = async (query, date = '') => {
    try {
      let url = `https://newsapi.org/v2/everything?q=${query}&apiKey=${apiKeys.general}`;

      if (date) {
        url += `&from=${date}&to=${date}`;
      }

      const response = await fetch(url);
      const data = await response.json();
      setArticles(data.articles);
    } catch (error) {
      console.error('Error fetching search results:', error);
    }
  };

  useEffect(() => {
    if (!isSearching) {
      fetchNews(selectedCategory, selectedDate);
    }
  }, [selectedCategory, isSearching, selectedDate]);

  const handleCategoryClick = (categoryName) => {
    setSelectedCategory(categoryName);
    setIsSearching(false);
    setSearchQuery('');
    Cookies.set('selectedCategory', categoryName, { expires: 7 });
  };

  const handleSearch = async (event) => {
    event.preventDefault();
    if (searchQuery) {
      const timestamp = new Date().toLocaleString();
      await fetchSearchResults(searchQuery, selectedDate);
      setIsSearching(true);

      const updatedHistory = [
        ...searchHistory,
        { query: searchQuery, date: selectedDate, timestamp }
      ];
      setSearchHistory(updatedHistory);

      Cookies.set('searchQuery', searchQuery, { expires: 7 });
      Cookies.set('searchDate', selectedDate, { expires: 7 });
    }
  };

  const handleDateChange = (event) => {
    setSelectedDate(event.target.value);
    Cookies.set('searchDate', event.target.value, { expires: 7 });
  };

  const handleLogout = () => {
    localStorage.removeItem('token');
    localStorage.removeItem('firstName');
    localStorage.removeItem('lastName');
    Cookies.remove('session_id');
    window.location.reload();
    navigate('/');
  };

  const handleSearchHistoryItemClick = (query) => {
    setSearchQuery(query.query);
    setSelectedDate(query.date);
    fetchSearchResults(query.query, query.date);
    setIsSearching(true);
    setIsDropdownOpen(false);
  };

  const handleDeleteSearchHistoryItem = (index) => {
    const updatedSearchHistory = [...searchHistory];
    updatedSearchHistory.splice(index, 1);
    setSearchHistory(updatedSearchHistory);
  };

  // Handling bookmark click behaviour for saving
  const handleBookmarkClick = async (article) => {
    // If article is already bookmarked, remove from bookmarks
    if (bookmark.some(bookmarked => bookmarked.url === article.url)) {
      try {
        // Removing bookmark from backend
        const response = await fetch('http://localhost:3000/api/users/bookmarks', {
          method: 'DELETE',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({
            title: article.title,
            url: article.url
          }),
        });

        // If response successful
        if (response.ok) {
          setBookmark(bookmark.filter(bookmarked => bookmarked.url !== article.url));
        } else {
          console.error('Failed to remove bookmark');
        }
      } catch (error) {
        console.error('Error with removing bookmark', error);
      }
    } else {  // Adding bookmark if article not yet toggled
      try {
        // Adding bookmark to backend
        const response = await fetch('http://localhost:3000/api/users/bookmarks', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({
            title: article.title,
            url: article.url
          }),
        });

        if (response.ok) {
          setBookmark([...bookmark, article]);
        } else {
          console.error('Failed to add to bookmarks');
        }
      } catch (error) {
        console.error('Error with adding bookmark', error);
      }
    }
  };

  return (
    <div className={styles.container}>
      <div className={styles.sidebar}>
        <div className={styles.sidebarHeader}>
          <h2><span>News</span></h2>
        </div>
        <ul className={styles.sidebarList}>
          {categories.map((cat, index) => (
            <li
              key={index}
              className={`${styles.sidebarItem} ${selectedCategory === cat.name && !isSearching ? styles.sidebarItemSelected : ''}`}
              onClick={() => handleCategoryClick(cat.name)}
            >
              {cat.icon}
              <span>{cat.name.charAt(0).toUpperCase() + cat.name.slice(1)}</span>
            </li>
          ))}
        </ul>
        <button className={styles.white_btn} onClick={handleLogout}>
          Logout
        </button>
      </div>

      <div className={`${styles.mainContent}`}>
        <div className={styles.welcomeMessage}>
          {userName && userLastName && <h2>Welcome, {userName} {userLastName}!</h2>}
        </div>

        <div className={styles.navBar}>
          <div className={styles.searchContainer} ref={dropdownRef}>
            <input
              type="text"
              placeholder="Search..."
              className={styles.searchInput}
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              onClick={toggleDropdown}
            />
            <button className={styles.searchButton} onClick={handleSearch}>
              Search
            </button>

            {isDropdownOpen && (
              <div className={styles.searchHistoryDropdown}>
                {searchHistory.map((item, index) => (
                  <div
                    key={index}
                    className={styles.searchHistoryItem}
                    onClick={() => handleSearchHistoryItemClick(item)}
                  >
                    <div>
                      <span>{item.query}</span>
                      <span className={styles.timestamp}>{item.date ? ` ${item.date}` : ''}</span>
                    </div>
                    <button
                      className={styles.deleteButton}
                      onClick={(e) => {
                        e.stopPropagation();
                        handleDeleteSearchHistoryItem(index);
                      }}
                    >
                      Delete
                    </button>
                  </div>
                ))}
              </div>
            )}
          </div>
          <input
            type="date"
            className={styles.datePicker}
            value={selectedDate}
            onChange={handleDateChange}
          />
        </div>

        <h2 className={styles.categoryTitle}>
          {isSearching ? `Showing results for '${searchQuery}'` : `${selectedCategory.charAt(0).toUpperCase() + selectedCategory.slice(1)} News in Malaysia`}
        </h2>

        <div className={styles.articles}>
          {articles.length > 0 ? (
            articles.map((article, index) => (
              <div key={index} className={styles.articleCard}>
                <h2>{article.title}</h2>
                <p>{article.description}</p>
                <a href={article.url} target="_blank" rel="noopener noreferrer">Read more</a>
                <button onClick={() => handleBookmarkClick(article)}>
                  {bookmark.some(bookmarked => bookmarked.url === article.url) ? <FaBookmark /> : <FaRegBookmark />}
                </button>
              </div>
            ))
          ) : (
            <p>No articles available</p>
          )}
        </div>
      </div>
    </div>
  );
};

export default HomeScreen;
