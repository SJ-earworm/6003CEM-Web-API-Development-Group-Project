const express = require('express');
const router = express.Router();
const { User } = require('../models/user');
const Joi = require('joi');
const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');

router.post('/', async (req, res) => {
    const { error } = validate(req.body);
    if (error) return res.status(400).send({ message: error.details[0].message });

    const user = await User.findOne({ email: req.body.email });
    if (!user) return res.status(400).send({ message: "Invalid email or password." });

    const validPassword = await bcrypt.compare(req.body.password, user.password);
    if (!validPassword) return res.status(400).send({ message: "Invalid email or password." });

    const token = jwt.sign({ _id: user._id }, process.env.JWTPRIVATEKEY, { expiresIn: "7d" });

    // Set cookie with token
    res.cookie('session_id', token, { httpOnly: true });

    // Log the cookie in the terminal
    console.log('Set-Cookie header:', res.get('Set-Cookie'));

    res.send({
        message: 'Login successful',
        firstName: user.firstName,
        lastName: user.lastName,
        email: user.email
    });
});

const validate = (data) => {
    const schema = Joi.object({
        email: Joi.string().email().required().label("Email"),
        password: Joi.string().required().label("Password"),
    });
    return schema.validate(data);
};

module.exports = router;
