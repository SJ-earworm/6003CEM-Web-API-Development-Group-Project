import React, { useEffect, useState } from 'react';
import { FaBookmark, FaRegBookmark } from 'react-icons/fa';
import './App.css';

function Bookmarks() {
    const [articles, setArticles] = useState([]);
    const [bookmark, setBookmark] = useState([]);

    const handleBookmarkClick = async (article) => {
        // new handleBookmark logic
        let path, mthod, consoleStatus;
    
        if (bookmark.some(bookmarked => bookmarked.url === article.url)){
          // set delete path & method when user wants to remove article from bookmarks
          path = 'deleteBookmark';
          mthod = 'DELETE';
          consoleStatus = 'deleting';
        } else {
          // set add path & method when user wants to remove article from bookmarks
          path = 'addBookmark';
          mthod = 'POST';
          consoleStatus = 'adding';
        }
    
          
        try {
          // connecting to backend operations
          const token = localStorage.getItem("token");
          const email = localStorage.getItem("email");
          console.log(`sending request to ${path} route`);
    
          const response = await fetch(`http://localhost:5000/api/users/${path}`, {
            method: `${mthod}`,
            headers: {
              'Content-Type': 'application/json',
              'Authorization': `${token}`
            },
            body: JSON.stringify({
              title: article.title,
              url: article.url,
              email: email
            }),
          });
    
          if(response.ok) {
            console.log(`Successful ${mthod} request`);
          }
        } catch (error) {
          console.error(`Error with ${consoleStatus} bookmark`, error);
        }
        
      }

    useEffect(() => {
        const fetchBookmarks = async () => {
            try {
                const token = localStorage.getItem("token");
                const email = localStorage.getItem("email");

                const response = await fetch('http://localhost:5000/api/users/fetchExistBookmarks', {
                    method: 'GET',
                    headers: {
                        'Content-Type': 'application/json',
                        'Authorization': `${token}`,
                        'User-Email': `${email}`
                    }
                });

                if(response.ok){
                    const userBookmarks = await response.json();
                    console.log(userBookmarks);  // Log the response data
                    setArticles(userBookmarks);
                }
            } catch (error) {
                console.error('Error fetching news:', error);
            }
        };

        fetchBookmarks();
    }, []);
    

    return (
        <div className="App">
            <header className="App-header">
                <h1>My Bookmarks</h1>
            </header>
            <div className="news-container">
                {articles.length > 0 ? (
                    articles.map((article, index) => (
                        <div key={index} className="news-article">
                            <h2>{article.title}</h2>
                            <p>{article.description}</p>
                            <a href={article.url} target="_blank" rel="noopener noreferrer">Read more</a>
                            <button onClick={() => handleBookmarkClick(article)}>
                                {bookmark.some(bookmarked => bookmarked.url === article.url) ? <FaBookmark/> : <FaRegBookmark/>}
                            </button>
                        </div>
                    ))
                ) : (
                    <p>No news articles found.</p>
                )}
            </div>
        </div>
    );
}

export default Bookmarks;
