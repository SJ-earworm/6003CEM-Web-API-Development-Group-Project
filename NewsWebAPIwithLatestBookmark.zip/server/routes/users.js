const express = require("express");
const router = express.Router();
const { User, validate } = require("../models/user");
const bcrypt = require("bcrypt");
// const auth = require("../middleware/midware_auth");

// Route to handle POST requests to create a new user
const jwt = require('jsonwebtoken');

router.post('/', async (req, res) => {
    try {
        // Validate the request body data
        const { error } = validate(req.body);
        if (error) return res.status(400).send({ message: error.details[0].message });

        // Check if the user already exists
        let user = await User.findOne({ email: req.body.email });
        if (user) return res.status(409).send({ message: 'User with given email already exists!' });

        // Hash the password
        const salt = await bcrypt.genSalt(Number(process.env.SALT));
        const hashedPassword = await bcrypt.hash(req.body.password, salt);

        // Create a new user object with hashed password
        user = new User({
            firstName: req.body.firstName,
            lastName: req.body.lastName,
            email: req.body.email,
            password: hashedPassword
        });

        // Save the user to the database
        await user.save();

        // Generate JWT token
        const token = jwt.sign({ _id: user._id }, process.env.JWTPRIVATEKEY, { expiresIn: "7d" });

        // Set cookie with token
        res.cookie('session_id', token, { httpOnly: true });

        // Log the cookie in the terminal
        console.log('Set-Cookie header:', res.get('Set-Cookie'));

        // Respond with success message
        res.status(201).send({ message: 'User created successfully' });
    } catch (error) {
        // Handle server errors
        console.error(error);
        res.status(500).send({ message: 'Internal Server Error' });
    }
});



// Endpoint to capture search history
router.post('/search', async (req, res) => {
    const { userId, query } = req.body; // Assuming userId is passed from authentication middleware

    try {
        console.log('Received search request:', req.body); // Log request body to check incoming data

        // Find the user by ID and update search history
        const user = await User.findById(userId);
        if (!user) return res.status(404).send('User not found');

        // Push the new query to search history
        user.searchHistory.push(query);
        await user.save();

        console.log('Search query recorded successfully:', query); // Log success message

        res.json({ message: 'Search query recorded successfully' });
    } catch (error) {
        console.error('Error capturing search history:', error.message);
        res.status(500).send('Server Error');
    }
});
module.exports = router;

// Endpoint to retrieve search history
router.get('/search/history/:userId', async (req, res) => {
    const userId = req.params.userId;

    try {
        // Find the user by ID and retrieve search history
        const user = await User.findById(userId);
        if (!user) return res.status(404).send('User not found');

        // Return search history as response
        res.json({ searchHistory: user.searchHistory });
    } catch (error) {
        console.error('Error retrieving search history:', error.message);
        res.status(500).send('Server Error');
    }
});
module.exports = router;


// Pulling bookmarks from db
router.get("/fetchExistBookmarks", async (req, res) => {
    console.log('Entered /fetchExistBookmarks backend');
    try {
        const token = req.header('Authorization'); // retrieving token from header
        const email = req.header('User-Email'); // retrieving user email from header
        if(!token)return res.status(404).send('User not found');

        // finding existence of current user in db
        const userBookmarks = await User.findOne({email}).select('bookmarks');
        
        // if bookmark or user not found
        if (!userBookmarks) {
            console.error('User/bookmark not found', error);
        }

        // filtering the title & url retrieved from .select()
        const fltrBkmrkAttributes = userBookmarks.bookmarks.map(bookmark => ({
            title: bookmark.title,
            url: bookmark.url
        }))

        if (fltrBkmrkAttributes && fltrBkmrkAttributes.length > 0) {
            console.log('userBookmarks: ', fltrBkmrkAttributes);
            return res.status(200).send(fltrBkmrkAttributes); // sending bookmarks to frontend if exists
        } else {
            return res.status(404).send('No bookmark found');
        }
    } catch(error) {
        res.status(500).send('Server error');
        console.error('Error: ', error);
    };
});


// Adding bookmarks
router.post("/addBookmark", async (req, res) => {
    // display message if fetch request succeeded
    console.log('request made it to the /addBookmark router');

    try {
        const token = req.header('Authorization'); // retrieving token from the header
        const {title, url, email} = req.body;
        if(!token)return res.status(404).send('User not found');

        // inserting bookmark into the user db collection
        User.findOne({email})
            .then(matchingUser => {
                // if user email not found in db
                if(!matchingUser){
                    console.error('User not found', error);
                }

                // check if bookmark exists in db
                // if bookmark exists in db, send response indicating existence of the bookmark
                const bookmarkExists = matchingUser.bookmarks.some(bookmark => bookmark.url === url);
                if (bookmarkExists) {
                    const exists = true;
                    res.json({bookmarkStatus: exists});
                } else {
                    // adding bookmark into db
                    matchingUser.bookmarks.push({title, url});
                    matchingUser.save();
                }
                
            })
            .then(operationSuccess => {
                if(operationSuccess){
                    console.log(`Bookmark added to ${email}'s bookmarks`);
                }
            })
            .catch(error => console.error('Error finding user:', error));

        // respond with success message
        res.status(201).send("Add bookmark request succeeded");
    } catch(error) {
        res.status(500).send('Server error');
        console.error('Error: ', error);
    }
});

// Deleting bookmarks
router.delete("/deleteBookmark", async (req,res) => {
    console.log('request made it to /deleteBookmark router');
    try {
        const token = req.header('Authorization'); // retrieving token from the header
        const {title, url, email} = req.body;
        if(!token)return res.status(404).send('User not found');

        // finding the user email's db collection
        const user = await User.findOne({email});
        if (!user) {
            console.error('Cannot find user email: ', error);
        }

        // locating the bookmark to be deleted
        const bookmarkExists = user.bookmarks.some(bookmark => bookmark.url === url);
        if (!bookmarkExists){
            console.log('Bookmark is not found in the db'); // if bookmark not in the db
        }

        // removing bookmark from db
        try{
            console.log('removing bookmark');
            await User.updateOne(
                {email: email},
                {$pull: 
                    {bookmarks: {url: url}}
                }
            );
        } catch(error) {
            console.error('Error deleting bookmark: ', error); // if error in deleting bookmark
        }

        // respond with success message
        res.status(200).send('Successfully deleted bookmark');
    } catch(error) {
        res.status(500).send('Server error');
        console.error('Error: ', error);
    }
});

// Retrieving bookmarks
// router.get("/bookmarks", async (req, res) => {
//     try {
//         const user = await User.findById(req.session.userId); // used with with the implementation of express-session
//         if(!user) return res.status(404).send('User not found');

//         res.send(user.bookmarks);
//     } catch(error) {
//         res.status(500).send('Server error');
//     }
// });


module.exports = router;
