// Middleware authentication for website-wide session token usage
const auth = (req, res, next) => {
    if (!req.session.userId) {
        return res.status(401).send('Access denied');
    }
    next();
};

module.exports = auth;