require("dotenv").config();
const express = require("express");
const app = express();
const cors = require("cors");
const cookieParser = require("cookie-parser");
const connection = require("./db");
const userRoutes = require("./routes/users");
const authRoutes = require("./routes/auth");
const axios = require("axios");

// Database connection
connection();

// Add middlewares
app.use(express.json());
app.use(cors());
app.use(cors({
  origin: 'http://localhost:3000',
  credentials: true  //  enabling credentials to be sent (cookies)
}));
app.use(cookieParser());

// Routes
app.use("/api/users", userRoutes);
app.use("/api/auth", authRoutes);
const port = process.env.PORT || 3000;
app.listen(port, () => console.log(`Listening on port ${port}...`));

// Endpoint for sports news
// app.get('/api/news/sports', async (req, res) => {
//     try {
//         const response = await axios.get('https://newsapi.org/v2/top-headlines', {
//             params: {
//                 country: 'my',
//                 category: 'sports',
//                 apiKey: '7ca08a73c4b04972877d67101aabd31c'
//             }
//         });
//         res.json(response.data);
//     } catch (error) {
//         console.error('Error fetching sports news:', error.message);
//         res.status(500).send('Server Error');
//     }
// });


// Endpoint for sports news
app.get('/api/news/sports', async (req, res) => {
   try {
       const response = await axios.get('https://newsapi.org/v2/top-headlines', {
           params: {
               country: 'my',
               category: 'sports',
               apiKey: '7ca08a73c4b04972877d67101aabd31c'
           }
       });
       res.json(response.data);
   } catch (error) {
       console.error('Error fetching sports news:', error.message);
       res.status(500).send('Server Error');
    }
});

// Endpoint for tourism news
app.get('/api/news/tourism', async (req, res) => {
    try {
        const response = await axios.get('https://newsapi.org/v2/top-headlines', {
            params: {
                country: 'my',
                category: 'business', // Assuming 'business' for tourism category
                apiKey: 'ee3dad1511484effb0aebe5c03edf7bf'
            }
        });
        res.json(response.data);
    } catch (error) {
        console.error('Error fetching tourism news:', error.message);
        res.status(500).send('Server Error');
    }
});

// Endpoint for entertainment news
app.get('/api/news/entertainment', async (req, res) => {
    try {
        const response = await axios.get('https://newsapi.org/v2/top-headlines', {
            params: {
                country: 'my',
                category: 'entertainment',
                apiKey: '6e486882e2c14a678cec2533aefb571d'
            }
        });
        res.json(response.data);
    } catch (error) {
        console.error('Error fetching entertainment news:', error.message);
        res.status(500).send('Server Error');
    }
});

// Endpoint for science news
app.get('/api/news/science', async (req, res) => {
    try {
        const response = await axios.get('https://gnews.io/api/v4/top-headlines', {
            params: {
                topic: 'science',
                country: 'my',
                token: 'a49dc5caead5fc77840446f06500612b'
            }
        });
        res.json(response.data);
    } catch (error) {
        console.error('Error fetching science news:', error.message);
        res.status(500).send('Server Error');
    }
});





// test API
// app.get('/api/news/test', async (req, res) => {
//       try {
//           const response = await axios.get('https://newsapi.org/v2/top-headlines?sources=techcrunch&apiKey=a57601c40f484d69a8ab8d2c3b119888');
//           res.json(response.data);
//       } catch (error) {
//           console.error('Error fetching science news:', error.message);
//           res.status(500).send('Server Error');
//       }
// });