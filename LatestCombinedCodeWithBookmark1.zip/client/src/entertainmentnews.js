import React, { useEffect, useState } from 'react';
import axios from 'axios';
import { FaBookmark, FaRegBookmark } from 'react-icons/fa'; // Import the bookmark icons
import './App.css';

function EntertainmentNews() {
    const [articles, setArticles] = useState([]);
    const [bookmarks, setBookmarks] = useState([]); // Define the bookmarks state

    useEffect(() => {
        const fetchNews = async () => {
            try {
                const response = await axios.get('http://localhost:3000/api/news/entertainment');
                console.log(response.data);  // Log the response data
                setArticles(response.data.articles);
            } catch (error) {
                console.error('Error fetching news:', error);
            }
        };

        fetchNews();
    }, []);

    const handleBookmarkClick = (article) => {
        if (bookmarks.some(bookmarked => bookmarked.url === article.url)) {
            setBookmarks(bookmarks.filter(bookmarked => bookmarked.url !== article.url));
        } else {
            setBookmarks([...bookmarks, article]);
        }
    };

    return (
        <div className="App">
            <header className="App-header">
                <h1>Entertainment News in Malaysia</h1>
            </header>
            <div className="news-container">
                {articles.length > 0 ? (
                    articles.map((article, index) => (
                        <div key={index} className="news-article">
                            <h2>{article.title}</h2>
                            <p>{article.description}</p>
                            <a href={article.url} target="_blank" rel="noopener noreferrer">Read more</a>
                            <button onClick={() => handleBookmarkClick(article)}>
                                {bookmarks.some(bookmarked => bookmarked.url === article.url) ? <FaBookmark /> : <FaRegBookmark />}
                            </button>
                        </div>
                    ))
                ) : (
                    <p>No news articles found.</p>
                )}
            </div>
        </div>
    );
}

export default EntertainmentNews;