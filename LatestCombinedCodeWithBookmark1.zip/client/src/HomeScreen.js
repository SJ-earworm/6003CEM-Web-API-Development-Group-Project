import React, { useState, useEffect, useRef } from 'react';
import { FaHome, FaBusinessTime, FaTv, FaFlask, FaFootballBall, FaBookmark, FaRegBookmark } from 'react-icons/fa';
import { useNavigate } from 'react-router-dom';
import styles from './HomeScreen.module.css';

const API_URL = 'https://newsapi.org/v2/top-headlines';
const GNEWS_URL = 'https://gnews.io/api/v4/top-headlines';

const categories = [
  { name: 'general', icon: <FaHome /> },
  { name: 'business', icon: <FaBusinessTime /> },
  { name: 'entertainment', icon: <FaTv /> },
  { name: 'science', icon: <FaFlask /> },
  { name: 'sports', icon: <FaFootballBall /> },
  { name: 'bookmarks', icon: <FaRegBookmark /> },
];

const apiKeys = {
  general: '3e9128eac68a438482b1fbff3b75ba0d',
  business: 'ee3dad1511484effb0aebe5c03edf7bf',
  entertainment: '6e486882e2c14a678cec2533aefb571d',
  science: 'a49dc5caead5fc77840446f06500612b',
  sports: '7ca08a73c4b04972877d67101aabd31c',
};

const HomeScreen = () => {
  const [selectedCategory, setSelectedCategory] = useState('general');
  const [articles, setArticles] = useState([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [isSearching, setIsSearching] = useState(false);
  const [selectedDate, setSelectedDate] = useState('');
  const navigate = useNavigate();
  const [userName, setUserName] = useState('');
  const [userLastName, setUserLastName] = useState('');
  const [searchHistory, setSearchHistory] = useState([]);
  const [isDropdownOpen, setIsDropdownOpen] = useState(false); // State to track dropdown visibility
  const [bookmark, setBookmark] = useState([]); // state to handle bookmark saving

  useEffect(() => {
    const firstName = localStorage.getItem('firstName');
    const lastName = localStorage.getItem('lastName');
    if (firstName) {
      setUserName(firstName);
    }
    if (lastName) {
      setUserLastName(lastName);
    }
  }, []);

  useEffect(() => {
    // Function to handle clicks outside dropdown
    const handleClickOutside = (event) => {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target)) {
        setIsDropdownOpen(false); // Close dropdown if clicked outside
      }
    };

    // Add event listener when dropdown is open
    if (isDropdownOpen) {
      document.addEventListener('mousedown', handleClickOutside);
    } else {
      document.removeEventListener('mousedown', handleClickOutside);
    }

    // Clean up event listener
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, [isDropdownOpen]);

  const dropdownRef = useRef(null); // Ref for the dropdown container

  const toggleDropdown = () => {
    setIsDropdownOpen(!isDropdownOpen); // Toggle dropdown visibility
  };

  const fetchNews = async (category, date = '') => {
    try {
      let url = category === 'science'
        ? `${GNEWS_URL}?topic=${category}&country=my&token=${apiKeys[category]}`
        : `${API_URL}?country=my&category=${category}&apiKey=${apiKeys[category]}`;

      if (date) {
        url += `&from=${date}&to=${date}`;
      }

      const response = await fetch(url);
      const data = await response.json();
      setArticles(data.articles);
    } catch (error) {
      console.error('Error fetching news:', error);
    }
  };

  const fetchSearchResults = async (query, date = '') => {
    try {
      let url = `https://newsapi.org/v2/everything?q=${query}&apiKey=${apiKeys.general}`;

      if (date) {
        url += `&from=${date}&to=${date}`;
      }

      const response = await fetch(url);
      const data = await response.json();
      setArticles(data.articles);
    } catch (error) {
      console.error('Error fetching search results:', error);
    }
  };

  useEffect(() => {
    if (!isSearching) {
      fetchNews(selectedCategory, selectedDate);
    }
  }, [selectedCategory, isSearching, selectedDate]);

  const handleCategoryClick = (categoryName) => {
    setSelectedCategory(categoryName);
    setIsSearching(false);
    setSearchQuery('');
  };

  const handleSearch = (event) => {
    event.preventDefault();
    if (searchQuery) {
      console.log('Current search query:', searchQuery);
      fetchSearchResults(searchQuery, selectedDate);
      setIsSearching(true);

      if (!searchHistory.includes(searchQuery)) {
        const updatedHistory = [...searchHistory, searchQuery];
        console.log('Updating search history:', updatedHistory);
        setSearchHistory(updatedHistory);
      } else {
        console.log('Search query already in history.');
      }
    } else {
      console.log('Search query is empty.');
    }
  };

  const handleDateChange = (event) => {
    setSelectedDate(event.target.value);
    if (isSearching && searchQuery) {
      fetchSearchResults(searchQuery, event.target.value);
    } else {
      fetchNews(selectedCategory, event.target.value);
    }
  };

  const handleLogout = () => {
    localStorage.removeItem('token');
    localStorage.removeItem('firstName');
    localStorage.removeItem('lastName');
    window.location.reload();
    navigate('/');
  };

  const handleSearchHistoryItemClick = (query) => {
    setSearchQuery(query);
    fetchSearchResults(query, selectedDate);
    setIsSearching(true);
    setIsDropdownOpen(false); // Close dropdown after item click
  };

  const handleDeleteSearchHistoryItem = (index) => {
    const updatedSearchHistory = [...searchHistory];
    updatedSearchHistory.splice(index, 1);
    setSearchHistory(updatedSearchHistory);
  };

  // Handling bookmark click behaviour for saving
  const handleBookmarkClick = async (article) => {
    // new handleBookmark logic
    let path, mthod, consoleStatus;

    if (bookmark.some(bookmarked => bookmarked.url === article.url)){
      // set delete path & method when user wants to remove article from bookmarks
      path = 'deleteBookmark';
      mthod = 'DELETE';
      consoleStatus = 'deleting';
    } else {
      // set add path & method when user wants to remove article from bookmarks
      path = 'addBookmark';
      mthod = 'POST';
      consoleStatus = 'adding';
    }

      
    try {
      // connecting to backend operations
      const token = localStorage.getItem("token");
      const email = localStorage.getItem("email");
      console.log(`sending request to ${path} route`);

      const response = await fetch(`http://localhost:3000/api/users/${path}`, {
        method: `${mthod}`,
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `${token}`
        },
        body: JSON.stringify({
          title: article.title,
          url: article.url,
          email: email
        }),
      });

      if(response.ok) {
        console.log(`Successful ${mthod} request`);
      }
    } catch (error) {
      console.error(`Error with ${consoleStatus} bookmark`, error);
    }
    
  }

  // fetch bookmarked articles from db
  const fetchBookmarks = async () => {
    const token = localStorage.getItem("token");
    const email = localStorage.getItem("email");

    try {
      console.log('request going into the backend');
      const response = await fetch('http://localhost:3000/api/users/fetchExistBookmarks', {
        method: 'GET',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `${token}`,
          'User-Email': `${email}`
        }
      });
  
      if(response.ok) {
        console.log('request came back out into frontend, bkmarkExist.ok block')

        const userBookmarks = await response.json(); // extracting user bookmarks from backend response
        console.log('fetchBookmarks() response value: ', userBookmarks);
        setBookmark(userBookmarks); // retrieved bookmark urls from the backend
        // console.log('final bookmark state: ', bookmark);
      }
    } catch(error) {
      console.error('Error fetching bookmarks: ', error);
    }    
  }

  // test API
  // const fetchTestAPI = async () => {
  //   try {
  //     const response = await fetch('http://localhost:3000/api/news/test');
  //     const data = await response.json();
  //     setArticles(data.articles);
  //   } catch(error) {
  //     console.error('Error loading test API articles', error);
  //   }
  // }

  // temporary dummy article data
  useEffect(() => {
    // const dummyArticles = [
    //   {
    //     title: 'Dummy article 1',
    //     description: 'Lorem ipsum jibber jabber',
    //     url: 'test123'
    //   },
    //   {
    //     title: 'Dummy article 2',
    //     description: 'Lorem ipsum jibber jabber',
    //     url: '321test'
    //   },
    //   {
    //     title: 'Dummy article 3',
    //     description: 'Lorem ipsum jibber jabber',
    //     url: 'tset'
    //   }
    // ];
    // setArticles(dummyArticles);

    // fetching user's bookmarks
    fetchBookmarks();
    // fetchTestAPI();
  }, []); 

  // temp bookmark for state monitoring
  useEffect(() => {
    console.log('current [bookmark] state after loading: ', bookmark);
  }, [bookmark]);


  return (
    <div className={styles.container}>
      <div className={styles.sidebar}>
        <div className={styles.sidebarHeader}>
          <h2><span>News</span></h2>
        </div>
        <ul className={styles.sidebarList}>
          {categories.map((cat, index) => (
            <li
              key={index}
              className={`${styles.sidebarItem} ${selectedCategory === cat.name && !isSearching ? styles.sidebarItemSelected : ''}`}
              onClick={() => handleCategoryClick(cat.name)}
            >
              {cat.icon}
              <span>{cat.name.charAt(0).toUpperCase() + cat.name.slice(1)}</span>
            </li>
          ))}
        </ul>
        <button className={styles.white_btn} onClick={handleLogout}>
          Logout
        </button>
      </div>

      <div className={`${styles.mainContent}`}>
        <div className={styles.welcomeMessage}>
          {userName && userLastName && <h2>Welcome, {userName} {userLastName}!</h2>}
        </div>

        <div className={styles.navBar}>
          <div className={styles.searchContainer} ref={dropdownRef}>
            <input
              type="text"
              placeholder="Search..."
              className={styles.searchInput}
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              onClick={toggleDropdown} // Toggle dropdown on input click
            />
            <button className={styles.searchButton} onClick={handleSearch}>
              Search
            </button>

            {isDropdownOpen && (
              <div className={styles.searchHistoryDropdown}>
                {searchHistory.map((item, index) => (
                  <div key={index} className={styles.searchHistoryItem}>
                    <div onClick={() => handleSearchHistoryItemClick(item)}>
                      <span>{item}</span>
                    </div>
                    <button
                      className={styles.deleteButton}
                      onClick={() => handleDeleteSearchHistoryItem(index)}
                    >
                      Delete
                    </button>
                  </div>
                ))}
              </div>
            )}
          </div>
          <input
            type="date"
            className={styles.datePicker}
            value={selectedDate}
            onChange={handleDateChange}
          />
        </div>

        <h2 className={styles.categoryTitle}>
          {isSearching ? `Showing results for '${searchQuery}'` : `${selectedCategory.charAt(0).toUpperCase() + selectedCategory.slice(1)} News in Malaysia`}
        </h2>

        <div className={styles.articles}>
          {articles.length > 0 ? (
            articles.map((article, index) => (
              <div key={index} className={styles.articleCard}>
                <h2>{article.title}</h2>
                <p>{article.description}</p>
                <a href={article.url} target="_blank" rel="noopener noreferrer">Read more</a>
                {/* bookmark icon will change according to the bookmark status */}
                <button onClick={() => handleBookmarkClick(article)}>
                  {bookmark.some(bookmarked => bookmarked.url == article.url) ? (<FaBookmark/>) : (<FaRegBookmark/>)}
                </button>
              </div>
            ))
          ) : (
            <p>No articles available</p>
          )}
        </div>
      </div>
    </div>
  );
};

export default HomeScreen;
