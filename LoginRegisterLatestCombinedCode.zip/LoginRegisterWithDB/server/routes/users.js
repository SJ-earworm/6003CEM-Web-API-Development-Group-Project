const express = require("express");
const router = express.Router();
const { User, validate } = require("../models/user");
const bcrypt = require("bcrypt");

// Route to handle POST requests to create a new user
const jwt = require('jsonwebtoken');

router.post('/', async (req, res) => {
    try {
        // Validate the request body data
        const { error } = validate(req.body);
        if (error) return res.status(400).send({ message: error.details[0].message });

        // Check if the user already exists
        let user = await User.findOne({ email: req.body.email });
        if (user) return res.status(409).send({ message: 'User with given email already exists!' });

        // Hash the password
        const salt = await bcrypt.genSalt(Number(process.env.SALT));
        const hashedPassword = await bcrypt.hash(req.body.password, salt);

        // Create a new user object with hashed password
        user = new User({
            firstName: req.body.firstName,
            lastName: req.body.lastName,
            email: req.body.email,
            password: hashedPassword
        });

        // Save the user to the database
        await user.save();

        // Generate JWT token
        const token = jwt.sign({ _id: user._id }, process.env.JWTPRIVATEKEY, { expiresIn: "7d" });

        // Set cookie with token
        res.cookie('session_id', token, { httpOnly: true });

        // Log the cookie in the terminal
        console.log('Set-Cookie header:', res.get('Set-Cookie'));

        // Respond with success message
        res.status(201).send({ message: 'User created successfully' });
    } catch (error) {
        // Handle server errors
        console.error(error);
        res.status(500).send({ message: 'Internal Server Error' });
    }
});



// Endpoint to capture search history
router.post('/search', async (req, res) => {
    const { userId, query } = req.body; // Assuming userId is passed from authentication middleware

    try {
        console.log('Received search request:', req.body); // Log request body to check incoming data

        // Find the user by ID and update search history
        const user = await User.findById(userId);
        if (!user) return res.status(404).send('User not found');

        // Push the new query to search history
        user.searchHistory.push(query);
        await user.save();

        console.log('Search query recorded successfully:', query); // Log success message

        res.json({ message: 'Search query recorded successfully' });
    } catch (error) {
        console.error('Error capturing search history:', error.message);
        res.status(500).send('Server Error');
    }
});
module.exports = router;

// Endpoint to retrieve search history
router.get('/search/history/:userId', async (req, res) => {
    const userId = req.params.userId;

    try {
        // Find the user by ID and retrieve search history
        const user = await User.findById(userId);
        if (!user) return res.status(404).send('User not found');

        // Return search history as response
        res.json({ searchHistory: user.searchHistory });
    } catch (error) {
        console.error('Error retrieving search history:', error.message);
        res.status(500).send('Server Error');
    }
});
module.exports = router;


module.exports = router;
