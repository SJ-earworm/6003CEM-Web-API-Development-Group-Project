import React, { useState, useEffect, useRef } from 'react';
import { FaHome, FaBusinessTime, FaTv, FaFlask, FaFootballBall } from 'react-icons/fa';
import { useNavigate } from 'react-router-dom';
import styles from './HomeScreen.module.css';

const API_URL = 'https://newsapi.org/v2/top-headlines';
const GNEWS_URL = 'https://gnews.io/api/v4/top-headlines';

const categories = [
  { name: 'general', icon: <FaHome /> },
  { name: 'business', icon: <FaBusinessTime /> },
  { name: 'entertainment', icon: <FaTv /> },
  { name: 'science', icon: <FaFlask /> },
  { name: 'sports', icon: <FaFootballBall /> },
];

const apiKeys = {
  general: '54620fa26a0648fdb7ef7784abceccf1',
  business: 'ee3dad1511484effb0aebe5c03edf7bf',
  entertainment: '6e486882e2c14a678cec2533aefb571d',
  science: 'a49dc5caead5fc77840446f06500612b',
  sports: '7ca08a73c4b04972877d67101aabd31c',
};

const HomeScreen = () => {
  const [selectedCategory, setSelectedCategory] = useState('general');
  const [articles, setArticles] = useState([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [isSearching, setIsSearching] = useState(false);
  const [selectedDate, setSelectedDate] = useState('');
  const navigate = useNavigate();
  const [userName, setUserName] = useState('');
  const [userLastName, setUserLastName] = useState('');
  const [searchHistory, setSearchHistory] = useState([]);
  const [isDropdownOpen, setIsDropdownOpen] = useState(false); // State to track dropdown visibility

  useEffect(() => {
    const firstName = localStorage.getItem('firstName');
    const lastName = localStorage.getItem('lastName');
    if (firstName) {
      setUserName(firstName);
    }
    if (lastName) {
      setUserLastName(lastName);
    }
  }, []);

  useEffect(() => {
    // Function to handle clicks outside dropdown
    const handleClickOutside = (event) => {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target)) {
        setIsDropdownOpen(false); // Close dropdown if clicked outside
      }
    };

    // Add event listener when dropdown is open
    if (isDropdownOpen) {
      document.addEventListener('mousedown', handleClickOutside);
    } else {
      document.removeEventListener('mousedown', handleClickOutside);
    }

    // Clean up event listener
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, [isDropdownOpen]);

  const dropdownRef = useRef(null); // Ref for the dropdown container

  const toggleDropdown = () => {
    setIsDropdownOpen(!isDropdownOpen); // Toggle dropdown visibility
  };

  const fetchNews = async (category, date = '') => {
    try {
      let url = category === 'science'
        ? `${GNEWS_URL}?topic=${category}&country=my&token=${apiKeys[category]}`
        : `${API_URL}?country=my&category=${category}&apiKey=${apiKeys[category]}`;

      if (date) {
        url += `&from=${date}&to=${date}`;
      }

      const response = await fetch(url);
      const data = await response.json();
      setArticles(data.articles);
    } catch (error) {
      console.error('Error fetching news:', error);
    }
  };

  const fetchSearchResults = async (query, date = '') => {
    try {
      let url = `https://newsapi.org/v2/everything?q=${query}&apiKey=${apiKeys.general}`;

      if (date) {
        url += `&from=${date}&to=${date}`;
      }

      const response = await fetch(url);
      const data = await response.json();
      setArticles(data.articles);
    } catch (error) {
      console.error('Error fetching search results:', error);
    }
  };

  useEffect(() => {
    if (!isSearching) {
      fetchNews(selectedCategory, selectedDate);
    }
  }, [selectedCategory, isSearching, selectedDate]);

  const handleCategoryClick = (categoryName) => {
    setSelectedCategory(categoryName);
    setIsSearching(false);
    setSearchQuery('');
  };

  const handleSearch = async (event) => {
    event.preventDefault();
    if (searchQuery) {
      const timestamp = new Date().toLocaleString();
      await fetchSearchResults(searchQuery, selectedDate);
      setIsSearching(true);
  
      const updatedHistory = [
        ...searchHistory,
        { query: searchQuery, date: selectedDate, timestamp }
      ];
      setSearchHistory(updatedHistory);
    }
  };
  

  const handleDateChange = (event) => {
    setSelectedDate(event.target.value);
  };
  

  const handleLogout = () => {
    localStorage.removeItem('token');
    localStorage.removeItem('firstName');
    localStorage.removeItem('lastName');
    window.location.reload();
    navigate('/');
  };

  const handleSearchHistoryItemClick = (query) => {
    setSearchQuery(query.query);
    setSelectedDate(query.date);
    fetchSearchResults(query.query, query.date);
    setIsSearching(true);
    setIsDropdownOpen(false); // Close dropdown after item click
  };

  const handleDeleteSearchHistoryItem = (index) => {
    const updatedSearchHistory = [...searchHistory];
    updatedSearchHistory.splice(index, 1);
    setSearchHistory(updatedSearchHistory);
  };

  return (
    <div className={styles.container}>
      <div className={styles.sidebar}>
        <div className={styles.sidebarHeader}>
          <h2><span>News</span></h2>
        </div>
        <ul className={styles.sidebarList}>
          {categories.map((cat, index) => (
            <li
              key={index}
              className={`${styles.sidebarItem} ${selectedCategory === cat.name && !isSearching ? styles.sidebarItemSelected : ''}`}
              onClick={() => handleCategoryClick(cat.name)}
            >
              {cat.icon}
              <span>{cat.name.charAt(0).toUpperCase() + cat.name.slice(1)}</span>
            </li>
          ))}
        </ul>
        <button className={styles.white_btn} onClick={handleLogout}>
          Logout
        </button>
      </div>

      <div className={`${styles.mainContent}`}>
        <div className={styles.welcomeMessage}>
          {userName && userLastName && <h2>Welcome, {userName} {userLastName}!</h2>}
        </div>

        <div className={styles.navBar}>
          <div className={styles.searchContainer} ref={dropdownRef}>
            <input
              type="text"
              placeholder="Search..."
              className={styles.searchInput}
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              onClick={toggleDropdown} // Toggle dropdown on input click
            />
            <button className={styles.searchButton} onClick={handleSearch}>
              Search
            </button>

            {isDropdownOpen && (
              <div className={styles.searchHistoryDropdown}>
                {searchHistory.map((item, index) => (
                  <div
                    key={index}
                    className={styles.searchHistoryItem}
                    onClick={() => handleSearchHistoryItemClick(item)} // Click handler on whole item
                  >
                    <div>
                      <span>{item.query}</span>
                      <span className={styles.timestamp}>{item.date ? ` ${item.date}` : ''}</span>
                    </div>
                    <button
                      className={styles.deleteButton}
                      onClick={(e) => {
                        e.stopPropagation(); // Prevent dropdown from closing on delete button click
                        handleDeleteSearchHistoryItem(index);
                      }}
                    >
                      Delete
                    </button>
                  </div>
                ))}
              </div>
            )}
          </div>
          <input
            type="date"
            className={styles.datePicker}
            value={selectedDate}
            onChange={handleDateChange}
          />
        </div>

        <h2 className={styles.categoryTitle}>
          {isSearching ? `Showing results for '${searchQuery}'` : `${selectedCategory.charAt(0).toUpperCase() + selectedCategory.slice(1)} News in Malaysia`}
        </h2>

        <div className={styles.articles}>
          {articles.length > 0 ? (
            articles.map((article, index) => (
              <div key={index} className={styles.articleCard}>
                <h2>{article.title}</h2>
                <p>{article.description}</p>
                <a href={article.url} target="_blank" rel="noopener noreferrer">Read more</a>
              </div>
            ))
          ) : (
            <p>No articles available</p>
          )}
        </div>
      </div>
    </div>
  );
};

export default HomeScreen;
