import React, { useState, useEffect } from 'react';
import { FaHome, FaBusinessTime, FaTv, FaFlask, FaFootballBall } from 'react-icons/fa';
import styles from './HomeScreen.module.css';

const API_URL = 'https://newsapi.org/v2/top-headlines';
const GNEWS_URL = 'https://gnews.io/api/v4/top-headlines';

const categories = [
  { name: 'general', icon: <FaHome /> },
  { name: 'business', icon: <FaBusinessTime /> },
  { name: 'entertainment', icon: <FaTv /> },
  { name: 'science', icon: <FaFlask /> },
  { name: 'sports', icon: <FaFootballBall /> },
];

const apiKeys = {
  general: '7ca08a73c4b04972877d67101aabd31c',
  business: 'ee3dad1511484effb0aebe5c03edf7bf',
  entertainment: '6e486882e2c14a678cec2533aefb571d',
  science: 'a49dc5caead5fc77840446f06500612b',
  sports: '7ca08a73c4b04972877d67101aabd31c',
};

const HomeScreen = () => {
  const [selectedCategory, setSelectedCategory] = useState('general');
  const [articles, setArticles] = useState([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [isSearching, setIsSearching] = useState(false);
  const [selectedDate, setSelectedDate] = useState('');

  const fetchNews = async (category, date = '') => {
    try {
      let url, response, data;
      if (category === 'science') {
        url = `${GNEWS_URL}?topic=${category}&country=my&token=${apiKeys[category]}`;
        if (date) {
          url += `&from=${date}&to=${date}`;
        }
      } else {
        url = `${API_URL}?country=my&category=${category}&apiKey=${apiKeys[category]}`;
        if (date) {
          url += `&from=${date}&to=${date}`;
        }
      }
      response = await fetch(url);
      data = await response.json();
      setArticles(data.articles);
    } catch (error) {
      console.error('Error fetching news:', error);
    }
  };

  const fetchSearchResults = async (query, date = '') => {
    try {
      let url = `https://newsapi.org/v2/everything?q=${query}&apiKey=${apiKeys.general}`;
      if (date) {
        url += `&from=${date}&to=${date}`;
      }
      const response = await fetch(url);
      const data = await response.json();
      setArticles(data.articles);
    } catch (error) {
      console.error('Error fetching search results:', error);
    }
  };

  useEffect(() => {
    if (!isSearching) {
      fetchNews(selectedCategory, selectedDate);
    }
  }, [selectedCategory, isSearching, selectedDate]);

  const handleCategoryClick = (categoryName) => {
    setSelectedCategory(categoryName);
    setIsSearching(false);
    setSearchQuery('');
  };

  const handleSearch = (event) => {
    event.preventDefault();
    if (searchQuery) {
      fetchSearchResults(searchQuery, selectedDate);
      setIsSearching(true);
    }
  };

  const handleDateChange = (event) => {
    setSelectedDate(event.target.value);
    if (isSearching && searchQuery) {
      fetchSearchResults(searchQuery, event.target.value);
    } else {
      fetchNews(selectedCategory, event.target.value);
    }
  };

  return (
    <div className={styles.container}>
      {/* Sidebar */}
      <div className={styles.sidebar}>
        <div className={styles.sidebarHeader}>
          <h2><span>News</span></h2>
        </div>
        <ul className={styles.sidebarList}>
          {categories.map((cat, index) => (
            <li
              key={index}
              className={`${styles.sidebarItem} ${selectedCategory === cat.name && !isSearching ? styles.sidebarItemSelected : ''}`}
              onClick={() => handleCategoryClick(cat.name)}
            >
              {cat.icon}
              <span>{cat.name.charAt(0).toUpperCase() + cat.name.slice(1)}</span>
            </li>
          ))}
        </ul>
      </div>

      {/* Main Content */}
      <div className={`${styles.mainContent}`}>
        {/* Top Navigation Bar */}
        <div className={styles.navBar}>
          <input
            type="text"
            placeholder="Search..."
            className={styles.searchInput}
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
          />
          <button className={styles.searchButton} onClick={handleSearch}>
            Search
          </button>
          <input
            type="date"
            className={styles.datePicker}
            value={selectedDate}
            onChange={handleDateChange}
          />
        </div>

        {/* Category Title */}
        <h2 className={styles.categoryTitle}>
          {isSearching ? `Showing results for '${searchQuery}'` : `${selectedCategory.charAt(0).toUpperCase() + selectedCategory.slice(1)} News in Malaysia`}
        </h2>

        {/* Articles */}
        <div className={styles.articles}>
          {articles.length > 0 ? (
            articles.map((article, index) => (
              <div key={index} className={styles.articleCard}>
                <h2>{article.title}</h2>
                <p>{article.description}</p>
                <a href={article.url} target="_blank" rel="noopener noreferrer">Read more</a>
              </div>
            ))
          ) : (
            <p>No articles available</p>
          )}
        </div>
      </div>
    </div>
  );
};

export default HomeScreen;
